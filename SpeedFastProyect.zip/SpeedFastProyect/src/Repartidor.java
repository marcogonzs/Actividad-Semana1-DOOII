public class Repartidor {
    private String nombre;
    private int distancia;
    private boolean disponible;
    private boolean mochilaTermica;
    private int pesoMaximo;

    public Repartidor(String nombre, int distancia, boolean disponible, boolean mochilaTermica, int pesoMaximo){
        this.nombre=nombre;
        this.distancia=distancia;
        this.disponible=disponible;
        this.mochilaTermica=mochilaTermica;
        this.pesoMaximo=pesoMaximo;
    }

    public String getNombre(){
        return nombre;
    }

    public int getDistancia() {
        return distancia;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public boolean hasMochilaTermica() {
        return mochilaTermica;
    }

    public int getPesoMaximo() {
        return pesoMaximo;
    }
}
