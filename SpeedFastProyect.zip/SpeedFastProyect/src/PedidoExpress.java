import java.util.List;

public class PedidoExpress extends Pedido {

    public PedidoExpress(int idPedido, String direccionEntrega) {
        super(idPedido, direccionEntrega, "Express");
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("Pedido Express");
        System.out.println("asignando repartidor");
    }

    //sobrecarga con busqueda del mas cercano
    public void asignarRepartidor(List<Repartidor> repartidores) {
        Repartidor masCercano = null;

        for (Repartidor r : repartidores) {
            if (r.isDisponible()) {
                if (masCercano == null || r.getDistancia() < masCercano.getDistancia()) {
                    masCercano = r;
                }
            }
        }
        if (masCercano != null) {
            System.out.println("Repartidor cercano encontrado.");
            System.out.println("Pedido asignado a " + masCercano.getNombre());
        } else {
            System.out.println("No hay repartidores disponibles.");
        }
    }

}