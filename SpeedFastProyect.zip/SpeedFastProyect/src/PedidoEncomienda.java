import java.util.List;

public class PedidoEncomienda extends Pedido {

    private int pesoEncomienda;

    public PedidoEncomienda(int idPedido, String direccionEntrega, int pesoEncomienda) {
        super(idPedido, direccionEntrega, "Encomienda");
        this.pesoEncomienda=pesoEncomienda;
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("Pedido: Encomienda");
        System.out.println("Asignando a repartidor");
        System.out.println("Validando peso de encomienda");
    }

    public void asignarRepartidor(List<Repartidor> repartidores){
        for (Repartidor r: repartidores){
            if(r.isDisponible()&&r.getPesoMaximo()>= pesoEncomienda){
                System.out.printf("Peso validado correctamente");
                System.out.println("Pedido asignado a "+r.getNombre());
                return;
            }
        }
        System.out.println("No hay repartidores disponibles para esta encomienda");
    }
}
