import java.util.List;

public class PedidoComida extends Pedido {

    public PedidoComida(int idPedido, String direccionEntrega) {
        super(idPedido, direccionEntrega, "Comida");
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("Pedido de Comida");
        System.out.println("Asignando a repartidor");
        System.out.println(" ");
    }

    //sobrecarga
    public void asignarRepartidor(List<Repartidor> repartidores) {
        for (Repartidor r : repartidores) {
            if (r.isDisponible() && r.hasMochilaTermica()) {
                System.out.println("Mochila Termica OK");
                System.out.println("Pedido asignado a " + r.getNombre());
                return;
            }
        }
        System.out.println("No hay repartidores con mochila termica disponible");
    }
}
