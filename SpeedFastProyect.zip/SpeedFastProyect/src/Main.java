import java.util.List;
import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        System.out.println("Hello and welcome!");
        List<Repartidor> repartidores = new ArrayList<>();
        repartidores.add(new Repartidor("Juan Perez",70, true,false,20p));
        repartidores.add(new Repartidor("Jose Diaz",50, true,true,10));
        repartidores.add(new Repartidor("Manuel Soto",30, true,true,15));

        //pedidos:
        PedidoComida pedidoComida=new PedidoComida(111,"Av. Esmeralda 123, Colina");
        PedidoEncomienda pedidoEncomienda = new PedidoEncomienda(222, "Freddy Maturana 456, Colina",17);
        PedidoExpress pedidoExpress= new PedidoExpress(333,"Av. Santa Filomena 789, colina");

        pedidoComida.asignarRepartidor();
        pedidoComida.asignarRepartidor(repartidores);

        System.out.println();

        pedidoEncomienda.asignarRepartidor();
        pedidoEncomienda.asignarRepartidor(repartidores);

        System.out.println();

        pedidoExpress.asignarRepartidor();
        pedidoExpress.asignarRepartidor(repartidores);


    }

}
